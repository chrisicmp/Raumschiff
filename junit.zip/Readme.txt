F�r Beschreibungen der Testmethoden siehe Javadoc-Kommentare in den jeweiligen .java Dateien.
Die Testklassen wurden beim Javadoc-Export nicht ber�cksichtigt.